React
Js

api:
https://fakestoreapi.com/users
https://fakestoreapi.com/products/categories
https://fakestoreapi.com/products